# dnd-5e-srd
The Dungeons and Dragons 5th Edition SRD converted to markdown and json
