### Giant Weasel

*Medium beast, unaligned*

**Armor Class** 13

**Hit Points** 9 (2d8)

**Speed** 40 ft.

| STR     | DEX     | CON     | INT    | WIS     | CHA    |
|---------|---------|---------|--------|---------|--------|
| 11 (+0) | 16 (+3) | 10 (+0) | 4 (-3) | 12 (+1) | 5 (-3) |

**Skills** Perception +3, Stealth +5

**Senses** darkvision 60 ft., passive Perception 13

**Languages** -

**Challenge** 1/8 (25 XP)

***Keen Hearing and Smell***. The weasel has advantage on Wisdom (Perception) checks that rely on hearing or smell.

###### Actions

***Bite***. *Melee Weapon Attack:* +5 to hit, reach 5 ft., one target. *Hit:* 5 (1d4+3) piercing damage.