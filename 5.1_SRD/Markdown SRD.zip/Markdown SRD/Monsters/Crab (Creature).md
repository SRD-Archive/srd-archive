### Crab

*Tiny beast, unaligned*

**Armor Class** 11 (natural armor)

**Hit Points** 2 (1d4)

**Speed** 20 ft., swim 20 ft.

| STR    | DEX     | CON     | INT    | WIS    | CHA    |
|--------|---------|---------|--------|--------|--------|
| 2 (-4) | 11 (+0) | 10 (+0) | 1 (-5) | 8 (-1) | 2 (-4) |

**Skills** Stealth +2

**Senses** blindsight 30 ft., passive Perception 9

**Languages** -

**Challenge** 0 (10 XP)

***Amphibious***. The crab can breathe air and water.

###### Actions

***Claw***. *Melee Weapon Attack:* +0 to hit, reach 5 ft., one target. *Hit:* 1 bludgeoning damage.