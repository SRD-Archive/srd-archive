### Riding Horse

*Large beast, unaligned*

**Armor Class** 10

**Hit Points** 13 (2d10+2)

**Speed** 60 ft.

| STR     | DEX     | CON     | INT    | WIS     | CHA    |
|---------|---------|---------|--------|---------|--------|
| 16 (+3) | 10 (+0) | 12 (+1) | 2 (-4) | 11 (+0) | 7 (-2) |

**Senses** passive Perception 10

**Languages** -

**Challenge** 1/4 (50 XP)

###### Actions

***Hooves***. *Melee Weapon Attack:* +5 to hit, reach 5 ft., one target. *Hit:* 8 (2d4+3) bludgeoning damage.