### Eagle

*Small beast, unaligned*

**Armor Class** 12

**Hit Points** 3 (1d6)

**Speed** 10 ft., fly 60 ft.

| STR    | DEX     | CON     | INT    | WIS     | CHA    |
|--------|---------|---------|--------|---------|--------|
| 6 (-2) | 15 (+2) | 10 (+0) | 2 (-4) | 14 (+2) | 7 (-2) |

**Skills** Perception +4

**Senses** passive Perception 14

**Languages** -

**Challenge** 0 (10 XP)

***Keen Sight***. The eagle has advantage on Wisdom (Perception) checks that rely on sight.

###### Actions

***Talons***. *Melee Weapon Attack:* +4 to hit, reach 5 ft., one target. *Hit:* 4 (1d4+2) slashing damage.