### Fire Giant

*Huge giant, lawful evil*

**Armor Class** 18 (plate)

**Hit Points** 162 (13d12+78)

**Speed** 30 ft.

| STR     | DEX    | CON     | INT     | WIS     | CHA     |
|---------|--------|---------|---------|---------|---------|
| 25 (+7) | 9 (-1) | 23 (+6) | 10 (+0) | 14 (+2) | 13 (+1) |

**Saving Throws** Dex +3, Con +10, Cha +5

**Skills** Athletics +11, Perception +6

**Damage Immunities** fire

**Senses** passive Perception 16

**Languages** Giant

**Challenge** 9 (5,000 XP)

###### Actions

***Multiattack***. The giant makes two greatsword attacks.

***Greatsword***. *Melee Weapon Attack:* +11 to hit, reach 10 ft., one target. *Hit:* 28 (6d6+7) slashing damage.

***Rock***. *Ranged Weapon Attack:* +11 to hit, range 60/240 ft., one target. *Hit:* 29 (4d10+7) bludgeoning damage.